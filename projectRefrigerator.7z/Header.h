#pragma once
#include "windows.h"
#include <iostream>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <iterator>
#include <vector>
#include <windows.h>
#include <unistd.h>
#include <clocale>
#include <chrono>
#include <ctime>
#include <thread>
using namespace std;

#define FRIDGE_CAP 240
#define DEF_FRIDGE_TEMP 13
#define FREEZER_CAP 130
#define DEF_FREEZER_TEMP -3




// abstract class for defining "env temperature", e.g. temp in a camera

class Envir {
private:
	int temp = 0;
public:
	Envir() : temp(10) {};
	Envir(int t) : temp(t) {};
	int GetTemp() {
		return temp;
	}
};


//class of an abstract cooling camera from which we can build complex systems

class AbstractCooler {

private:
	int freeSpace = 0;
	bool isDoorOpened = false;
	int currentTemp = 0;
	int wishedTemp = 0;
	bool isLightsOn = false;
	Envir* envir;
public:



	AbstractCooler(int currentTemp) {
		this->currentTemp = currentTemp;

	};

	AbstractCooler() {}

	int GetTemp() {
		return currentTemp;
	}

	void SetTemp(int t) {
		this->currentTemp = t;
	}


	void AbstractCooler_(int currentTemp, Envir* myenvir) {  //init a class with specified temp and volume e.g. fridge and freezer
		this->currentTemp = myenvir->GetTemp();
		this->wishedTemp = currentTemp;
		this->envir = myenvir;
	}


	void SetVolume(int v) {
		this->freeSpace = v;
	}

	int GetVolume() {
		return this->freeSpace;
	}

	bool DoorState() {
		return this->isDoorOpened;
	}

	void OpenDoor(bool open) {
		isDoorOpened = open;
	}

	void LightsOn(bool on) {
		isLightsOn = on;
	}

	bool LightsPowerState() {
		return this->isLightsOn;
	}





	int AddObject(int productNumber, int constMaxVolume) { //add a product to a camera
		// 1 item = 10
		int lim = 10 * productNumber;
		if (lim > constMaxVolume) {
			cout << "you cant place this many obj here\n";
			Sleep(2000);
			return -1;
		}
		else if (freeSpace < lim) {
			cout << "you cant place this many obj here\n";
			Sleep(2000);
			return -1;
		}
		else if (freeSpace >= 0 || freeSpace > lim) {
			freeSpace -= lim;
			cout << "freespace: " << freeSpace << endl;
		}
		else {
			return -1;
			cout << "error \n";
		}
		return freeSpace;
	}

	int RemObject(int productNumber, int constMaxVolume, int item_count) { //add a product to a camera
		// 1 item = 10
		int lim = 10 * productNumber;
		int over = freeSpace + lim;
		if (lim > constMaxVolume || over > constMaxVolume) {
			cout << "you cant take this many obj\n";
			Sleep(2000);
			return -1;
		}
		else if (freeSpace < constMaxVolume) {
			freeSpace += lim;
			item_count += productNumber;
			cout << "freespace: " << freeSpace << endl;
		}
		else {
			return NULL;
			cout << "error \n";
		}
		return freeSpace;
	}

};


class CoolerDoor
{
public:
    CoolerDoor();
    void setstate();
    bool getstate();
private:
    string material;
    bool state;
};
CoolerDoor::CoolerDoor()
{
    state = false;
    material = "Zalizo";
}
bool CoolerDoor::getstate()
{
cout << "State is get"<<endl;
return state;
}
void CoolerDoor::setstate()
{
    if (state == true)
    {
        state = false;
        cout << "Cooler door is closed\n";
    }
    else
    {
        state = true;
        cout << "Cooler door is opened\n";
    }
}

class Lightningsystem
{
public:
    Lightningsystem();
    bool poweron();
    bool poweroff();
private:
    int power;
    bool state;
};

Lightningsystem::Lightningsystem()
{
    power = rand() % 30 + 210; // 210-240 V
    state = false;
}

bool Lightningsystem::poweron()
{
    cout << " Power is on" <<endl;
    return true;
}

bool Lightningsystem::poweroff()
{
    cout << " Power is off" <<endl;
    return true;
}

class Doorcontrolsystem
{
public:
    Doorcontrolsystem();
    bool doorcheck();
    bool light();
    int getdoortime();
    bool sendsignal();
private:
    bool state;
};

Doorcontrolsystem::Doorcontrolsystem()
{
    state = false;
}

bool Doorcontrolsystem::doorcheck()
{
    cout << "Door is ok"<<endl;
    return true;
}

bool Doorcontrolsystem::light()
{
    cout << "Light is on" <<endl;
    return true;
}

bool Doorcontrolsystem::sendsignal()
{
    cout << "Signal is sent"<<endl;
    return true;
}
int Doorcontrolsystem::getdoortime()
{
cout << "Please close your door, it has already opened during:"<<rand()%70<<"seconds"<<endl;
return rand()%70;
}

class Cooler : public AbstractCooler {
private:
    int size = rand() % 10 + 130; // 130 - 135 L;
    string material = "Zalizo";;
    Lightningsystem lightning;
    Doorcontrolsystem doorcontrol;
    CoolerDoor door;
public:
	Cooler() {}
	Cooler(int currentTemp, Envir* myenvir) {
		AbstractCooler_(currentTemp, myenvir);
	}
};

class FreezerDoor
{
public:
    FreezerDoor();
    void setstate();
    bool getstate();
private:
    string material;
    bool state;
};
FreezerDoor::FreezerDoor()
{
    material = "zalizo";
    state = false;
}
bool FreezerDoor::getstate()
{
cout << "State was get"<<endl;
return state;
}
void FreezerDoor::setstate()
{
    if (state == true)
    {
        state = false;
        cout << "Door closed\n";
    }
    else
    {
        state = true;
        cout << "Door opened\n";
    }
}

class Freezer : public AbstractCooler {
    private:
    int size = rand() % 10 + 245; //245-255;
    string material = "Plastik";;
    FreezerDoor door;
public:
	Freezer() {}
	Freezer(int currentTemp, Envir* myenvir) {
		AbstractCooler_(currentTemp, myenvir);

	}
};



class Signalling
{
public:
    Signalling();
    bool sound();
private:
    int volume;
};

Signalling::Signalling()
{
   volume = 20;
}
bool Signalling::sound()
{
    cout << "Beep Beep Beep!"<<endl;
    return true;
}

class Screen
{
public:
    Screen();
    string getinput;
private:
    int size;
    bool state;
};
Screen::Screen()
{
    size = 10;
  //  cout <<"Checking the vitality of screen"<<endl<<"Type something:\n";
   // cin >> getinput;
   // cout << "Ok, your text is:"<< getinput <<endl<<endl;
    state = false;
}

class ControlPanel {
protected:
    int Mode = 3;
    int minTempFreezer = rand() % 2 + (-26); //-24 - -26
    int maxTempFreezer = rand() % 2 + (-3); //  -3 - -1
    int minTempCooler = rand() % 1 + 3; // 1 - 3
    int maxTempCooler = rand() % 2 + 13; // 13 - 15
    Signalling signalling;
    Screen screen;
	bool PowerOnStatus = false;
	string SystemName = "nosystemname";
public:
	string GetName() {
		return this->SystemName;
	}
	void SetPowerStatus(bool on) {
		this->PowerOnStatus = on;
	}
	bool GetPowerStatus() {
		return this->PowerOnStatus;
	}
	void TurnOn(string ControlPanelname, bool powerOnStatus) {
		if (powerOnStatus) {
			cout << "The " << ControlPanelname << " is already turned on\n";
		}
		else {
			SetPowerStatus(true);
			cout << "Turning on " << ControlPanelname << " ....... OK\n";
		}
	}
	void TurnOff(string ControlPanelname, bool powerOnStatus) {
		SetPowerStatus(false);
		cout << "Turning off " << ControlPanelname << " ....... OK\n";
	}
	void Working() {
		cout << this->SystemName << " working....";
	}
};

class Wire
{
public:
    Wire();
private:
    int length;
    string material;
};
Wire::Wire()
{
    length = rand() % 1 + (1,5); // 1.5 - 2 m
    material = "coaxial";
}

class Rosette
{
public:
    Rosette();
    void setstate();
    bool getstate();
private:
    string type;
    bool state;
};
Rosette::Rosette()
{
    type = "A++";
    state = false;
}
bool Rosette::getstate()
{
    return true;
}
void Rosette::setstate()
{
    if (state == true)
    {
        state = false;
        cout << "Power is off\n";
    }
    else
    {
        state = true;
        cout << "Power is on\n";
    }
}

class PowerSupplySystem : public ControlPanel {
private:
   Rosette rosette;
   Wire wire;
public:
    bool energysupply();
	PowerSupplySystem()
	 {
		this->PowerOnStatus = false;
		this->SystemName = "Electrical system";
	 }
};
bool PowerSupplySystem::energysupply()
{
    this->rosette.setstate();
    return true;
}


class TermoregulationSystem2
{
public:
    TermoregulationSystem2();
    void setTemps();
    void termoregulation();
private:
    bool state;
    int minTemp;
    int maxTemp;
};
TermoregulationSystem2::TermoregulationSystem2()
{
    state = false;
    minTemp = rand() % 1 + 3; // 1 - 3
    maxTemp = rand() % 2 + 13; // 13 - 15
}
void TermoregulationSystem2::setTemps()
{
cout << "Please, set min cooling temperature\n";
int a;
cin >> a;
if (a < rand() % 1 + 3)
{
    cout <<"Error, your temp is less min that it can be\n";
}
else
{
minTemp = a;
cout <<"Now your min temp is:"<<minTemp<<endl;
}
cout <<"Please, set max cooling temperature\n";
int b;
cin >>b;
if (b > rand() % 2 + 13)
{
    cout <<"Error, your temp is more max that it can be\n";
}
else
{
maxTemp = b;
cout <<"Now your max temp is:"<<maxTemp<<endl;
}
}
void TermoregulationSystem2::termoregulation()
{
cout << "Your min and max temperature now is:"<<minTemp<<maxTemp<<endl;
int a = rand() % 10; // random number of changing temperature
maxTemp = maxTemp - a; //changing maxTemp during sleep
minTemp = minTemp + a; //changing minTemp during sleep
sleep(90);
cout << "Now, your min and max temperature now is:"<<minTemp<<maxTemp<<endl;
}

class Temperatureloweringsystem2
{
public:
    Temperatureloweringsystem2();
    bool loweringTemp();
private:
    bool state;
};

Temperatureloweringsystem2::Temperatureloweringsystem2()
{
    state = false;
}

bool Temperatureloweringsystem2::loweringTemp()
{
cout << "Temperature is lowing"<<endl;
return true;
}

class CoolingSystem : public ControlPanel {
private:
TermoregulationSystem2 Termoregulation;
Temperatureloweringsystem2 loweringTemp;
public:
	CoolingSystem() {
		this->PowerOnStatus = false;
		this->SystemName = "Cooling system";
	}


	int SetTemp(bool poweredOn, Cooler &ccam, int t ) {
		if (poweredOn == false) {
			cout << "error\n";
		}
		else {
			int CurrentTemp = ccam.GetTemp();
			if (CurrentTemp == t) {
				cout << "Going to Control Panel\nentered value is a current one\n";
				Sleep(300);
				return 0;
			}
			else if (CurrentTemp > t) {
				cout << "brr cooling down...\n";
				int diff1 = CurrentTemp - t;
				for (int i = 0; i <= diff1; i++) {
					ccam.SetTemp(CurrentTemp--);
					cout << "current temp: " << ccam.GetTemp() << endl;
					Sleep(300);
				}
			}
			else if (CurrentTemp < t) {
                cout << "brr cooling up...\n";
				int diff2 = t - CurrentTemp;
				for (int i = 0; i <= diff2; i++) {
					ccam.SetTemp(CurrentTemp++);
					cout << "current temp: " << ccam.GetTemp() << endl;
					Sleep(300);
				}
			}
			return ccam.GetTemp();
		}
	}

	int InitialCooling(bool poweredOn, Cooler &ccam, Freezer &fcam, Envir* myenvir) {

		if (poweredOn==false) {
			cout << "error\n";
		}
		else {
			int EnteredTemp = myenvir->GetTemp();
			int diff1 = EnteredTemp - DEF_FRIDGE_TEMP;
            int diff2 = EnteredTemp + abs(DEF_FREEZER_TEMP);
			ccam.SetTemp(EnteredTemp);
			if (DEF_FRIDGE_TEMP >= EnteredTemp) {
				cout << endl;
				cout << "no need to cooling fridge\n"<<endl;
				return 0;
			}

			else {
				cout <<endl<< "brr cooling down... \n";
				for (int i = 0; i <= (diff1); i++) {
					ccam.SetTemp(EnteredTemp--);
					cout << "current fridge temp: " << ccam.GetTemp() << endl;
					Sleep(200);
				}
				cout << "Initial fridge temp set!\n";
				cout << endl;
			}
		}
	}

};


class Timer : public ControlPanel
{
public:
    Timer();
    bool countfreezertime();
    bool countcoolertime();
    bool countdoortime();
private:
    int freezertime;
    int coolertime;
    int doortime;
    bool state;
};

Timer::Timer()
{
    state = false;
    freezertime = 90; //90 c
    coolertime = rand() % 10 + 80; //80 - 90 c
    doortime = rand() % 10 + 60; //60 - 70 c
    this->PowerOnStatus = false;
    this->SystemName = "Timing system";
}

bool Timer::countfreezertime()
{
    if (freezertime >= 90)
    cout << "Freeze is ok. Checking Freeze Temperature"<<endl;
    return true;
}

bool Timer::countcoolertime()
{
    if (coolertime >= rand() % 10 + 80 )
    cout << "Cooler is ok. Checking Cooler Temperature"<<endl;
    return true;
}

bool Timer::countdoortime()
{
    if (doortime >= rand() % 10 + 60)
    cout << "Please close your door!"<<endl;
    return true;
}


class TermoregulationSystem1
{
public:
    TermoregulationSystem1();
    void setTemps();
    void termoregulation();
private:
    bool state;
    int minTemp;
    int maxTemp;
};
TermoregulationSystem1::TermoregulationSystem1()
{
    state = false;
    minTemp =rand() % 2 + (-26); //-24 - -26
    maxTemp = rand() % 2 + (-3); //  -3 - -1
}
void TermoregulationSystem1::setTemps()
{
cout << "Please, set min freezing temperature\n";
int a;
cin >> a;
if (a < rand() % 2 + (-26))
{
    cout <<"Error, your temp is more min that it can be\n";
}
else
{
minTemp = a;
cout <<"Now your min temp is:"<<minTemp<<endl;
}
cout <<"Please, set max freezing temperature\n";
int b;
cin >>b;
if (b > rand() % 2 + (-3))
{
    cout <<"Error, your temp is more max that it can be\n";
}
else
{
maxTemp = b;
cout <<"Now your max temp is:"<<maxTemp<<endl;
}
}
void TermoregulationSystem1::termoregulation()
{
cout << "Your min and max temperature now is:"<<minTemp<<maxTemp<<endl;
int a = rand() % 10; // random number of changing temperature
maxTemp = maxTemp - a; //changing maxTemp during sleep
minTemp = minTemp + a; //changing minTemp during sleep
sleep(90);
cout << "Now, your min and max temperature now is:"<<minTemp<<maxTemp<<endl;
}

class Temperatureloweringsystem1
{
public:
    Temperatureloweringsystem1();
    bool loweringTemp();
private:
    bool state;
};
Temperatureloweringsystem1::Temperatureloweringsystem1()
{
    state = false;
}
bool Temperatureloweringsystem1::loweringTemp()
{
    cout << "Temparute is lowing" <<endl;
    return true;
}

class FreezingSystem : public ControlPanel {
private:
TermoregulationSystem1 Termoregulation;
Temperatureloweringsystem1 loweringTemp;
public:
	FreezingSystem() {
		this->PowerOnStatus = false;
		this->SystemName = "Freezing system";
	}
	int SetTemp(bool poweredOn, Freezer &fcam, int t) {
		if (poweredOn == false) {
			cout << "error\n";
		}
		else {
			int CurrentTemp = fcam.GetTemp();
			if (CurrentTemp == t) {
				cout << "Going to Control Panel\nentered value is a current one\n";
				Sleep(300);
				return 0;
			}
			else if (CurrentTemp > t) {
				cout << "brr freezing down...\n";
				int diff1 = CurrentTemp - t;
				for (int i = 0; i <= diff1; i++) {
					fcam.SetTemp(CurrentTemp--);
					cout << "current temp: " << fcam.GetTemp() << endl;
					Sleep(300);
				}
			}
			else if (CurrentTemp < t) {
                cout << "brr freezing up...\n";
				int diff2 = t - CurrentTemp;
				for (int i = 0; i <= diff2; i++) {
					fcam.SetTemp(CurrentTemp++);
					cout << "current temp: " << fcam.GetTemp() << endl;
					Sleep(300);
				}
			}
			return fcam.GetTemp();
		}
	}
int InitialFreezing(bool poweredOn, Freezer &fcam, Envir* myenvir) {

		if (poweredOn==false) {
			cout << "error\n";
		}
		else {
			int EnteredTemp = myenvir->GetTemp();
			int diff2 = EnteredTemp + abs(DEF_FREEZER_TEMP);
			fcam.SetTemp(EnteredTemp);
			if (DEF_FREEZER_TEMP >= EnteredTemp) {
				cout << endl;
				cout << "no need to freezing down\n";
				return 0;
			}
            else {
				cout << "brr freezing down... \n";
				EnteredTemp = myenvir->GetTemp();			//this is important because we are manipulating local var, not the value in Envir object
				for (int i = 0; i <= (diff2); i++) {
					fcam.SetTemp(EnteredTemp--);
					cout << "current freezer temp: " << fcam.GetTemp() << endl;
					Sleep(200);
				}
				cout << "Initial freezer temp set!\n\n";
				cout << endl;
			}
		}
	}

};




class Refrigerator {
private:
	string name = "null";
	int weight, length, width, height = 0;
public:
	bool PowerOnStatus = false;
	PowerSupplySystem powersystem;
	CoolingSystem coolsys;
	FreezingSystem freezsys;
	Cooler CCam;
	Freezer FCam;
	Timer timer;
	Envir* envir;
	int c_item_count, f_item_count = 0;

	Refrigerator(string name, int weight, int length, int width, int height, int c_vol, int f_vol, Envir* myenvir) {
		this->name = name;
		this->weight = weight;
		this->length = length;
		this->width = width;
		this->height = height;
		this->envir = myenvir;
		CCam.SetVolume(c_vol);
		FCam.SetVolume(f_vol);
	}

	Refrigerator() {}

	string GetName() {
		return name;
	}

	void SetName(string name) {
		this->name = name;
	}

	int GetWeight() {
		return weight;
	}

	void SetWeight(int weight) {
		this->weight = weight;
	}

	int GetLength() {
		return length;
	}

	void SetLength(int length) {
		this->length = length;
	}

	int GetWidth() {
		return width;
	}

	void get_temp_test() {
		int i = envir->GetTemp();
		cout << "set temp: " << i << endl;
	}

	void SetWidth(int width) {
		this->width = width;
	}

	int GetHeight() {
		return height;
	}

	void SetHeight(int height) {
		this->height = height;
	}

	int GetFridgeVol() {
		return CCam.GetVolume();
	}

	void SetFridgeVol(int c_vol) {
		CCam.SetVolume(c_vol);
	}

	int GetFreezerVol() {
		return FCam.GetVolume();
	}

	void SetFreezerVol(int fr_vol) {
		FCam.SetVolume(fr_vol);
	}


	int AddObject_c(int num) {	//add a product to a fridge
		CCam.AddObject(num, FRIDGE_CAP);
		c_item_count += num;
		return CCam.GetVolume();
	}
	int AddObject_f(int num) {	//add a product to a freezer
		FCam.AddObject(num, FREEZER_CAP);
		f_item_count += num;
		return FCam.GetVolume();
	}

	int RemObject_c(int productNumber) { //add a product to a camera
		CCam.RemObject(productNumber, FRIDGE_CAP, c_item_count);
		c_item_count -= productNumber;
		return CCam.GetVolume();
	}

	int RemObject_f(int productNumber) { //add a product to a camera
		FCam.RemObject(productNumber, FREEZER_CAP, f_item_count);
		f_item_count -= productNumber;
		return FCam.GetVolume();
	}

	void OpenFridgeDoor() {
		CCam.OpenDoor(true);
		CCam.LightsOn(true);

		cout << "Fridge door opened" << endl;
		cout << "Light: ON" << endl;
		cout << "Free space: " << CCam.GetVolume() << endl;

	}

	void OpenFreezerDoor() {
		FCam.OpenDoor(true);
		FCam.LightsOn(true);
		cout << "Freezer door opened" << endl;
		cout << "Free space: " << FCam.GetVolume() << endl;
	}

	bool GetPowerStatus() {
		return this->PowerOnStatus;
	}

	void SetPowerStatus(bool on) {
		this->PowerOnStatus = on;
	}

	void StartSystems() {
		powersystem.TurnOn(powersystem.GetName(), powersystem.GetPowerStatus());
		Sleep(300);
		timer.TurnOn(timer.GetName(), timer.GetPowerStatus());
		Sleep(300);
		coolsys.TurnOn(coolsys.GetName(), coolsys.GetPowerStatus());
		Sleep(300);
		freezsys.TurnOn(freezsys.GetName(), freezsys.GetPowerStatus());
		Sleep(300);
	 	coolsys.InitialCooling(coolsys.GetPowerStatus(), CCam,FCam, envir);
	 	freezsys.InitialFreezing(freezsys.GetPowerStatus(), FCam, envir);
	}

	void StopSystems() {
		timer.TurnOff(timer.GetName(), timer.GetPowerStatus());
		Sleep(300);
		coolsys.TurnOff(coolsys.GetName(), coolsys.GetPowerStatus());
		Sleep(300);
		freezsys.TurnOff(freezsys.GetName(), freezsys.GetPowerStatus());
		Sleep(300);
		powersystem.TurnOff(powersystem.GetName(), powersystem.GetPowerStatus());
		Sleep(300);
	}

};


void Menu() {

	Envir komn_temp(10);
	int main_choice = 1;
	int choice = 1;
	int	 user_temp = 0;
	int desired_temp = 0;
	Refrigerator LG("LG", 75, 75, 65, 201, 240, 130, &komn_temp);

	cout << "Power on the fridge to get started\n";
	char ch;
	cout << "Do you want Power on the Refrigerator? Y/N\n";

	while (1) {
	cin >> ch;
	if (ch == 'y' or ch == 'Y') {
    cout << "Please enter current room temperature: \n"; //Ты остановился тут. Ты хотел добавить приветствие экрана. Также ты проверяешь что бы все было как по новому. Все что ниже этого, ок
	while (1) {
		cout << "temp: ";
		cin >> user_temp;
		cout << endl;
		if (user_temp > -10 || user_temp < 45) {
		komn_temp = Envir(user_temp);
		cout << "Ok, your the temperature in your room is: "<<user_temp<<endl<<endl;						// might get rid of "envir class" completely to simplify the logic and manually set the temp up
		break;
		}
		else {
			cout << "please enter correct temp\n";
		}
	}
        system("cls");
		LG.SetPowerStatus(true);
		LG.StartSystems();
		break;
	}
	else if (ch == 'n' or ch == 'N') {
		 cout << "Exiting....\n";
		 Sleep(500);
		 exit(0);
	}

	}




	while (choice != 0) {
		cout << endl;
		cout << endl;
		menu_ptr:
		cout << "           ACTION LIST\n     Made by Oleksii Chalyi, FB-81";
		cout << endl;
		cout << endl;
		cout << "Current fridge temp: " << LG.CCam.GetTemp() << endl;
		cout << "Current freezer temp: " << LG.FCam.GetTemp() << endl;
		cout << endl;
		cout << "0. Turn off the power and exit\n";
		cout << endl;
		cout << "1. Set fridge temp\n";
		cout << "2. Set freezer temp\n";
		cout << endl;
		cout << "3. Open fridge door \n";
		cout << "4. Open freezer door \n";
		cout << endl;


		cin >> choice;
		cout << "You choose: " << choice << endl;
		switch (choice) {
		case 0:							//exit
			system("cls");
			LG.StopSystems();
			cout << "Exiting....\n";
			break;
        		case 1:
			while (main_choice == 1) {
				system("cls");
				cout << "Current Fridge temperature: " << LG.CCam.GetTemp() << endl;
				cout << endl;
				cout << "1. Enter Fridge temperature you want to set:: \n";
				cout << "2. Go to ACTION LIST\n";
				cin >> choice;
				switch (choice) {
				case 1:
					cout << "You set: " << choice << endl;
					cout << "Setting Temperature: ";
					cin >> desired_temp;
					while ((desired_temp <= 1) || (desired_temp >= 13)) {
						cout << "Something going wrong. Try to set Temperature between 1 and 13\n";
						cin >> desired_temp;
					}
					LG.coolsys.SetTemp(true, LG.CCam, desired_temp);
				case 2:
					cout << "Getting back...\n";
					Sleep(100);
					goto menu_ptr;
				}
			}

		case 2:
			while (main_choice == 1) {
				system("cls");
				cout << "Current Freezer temperature: " << LG.FCam.GetTemp() << endl;
				cout << endl;
				cout << "1. Enter Freezer temperature you want to set: \n";
				cout << "2. Go to ACTION LIST\n";
				cin >> choice;
				switch (choice) {
				case 1:
					cout << "You set: " << choice << endl;
					cout << "Setting Temperature: ";
					cin >> desired_temp;
					while ((desired_temp <= -26) || (desired_temp >= -3)) {
						cout << "Something going wrong. Try to set Temperature between -26 and -3\n";
						cin >> desired_temp;
					}
					LG.freezsys.SetTemp(true, LG.FCam, desired_temp);
					break;
				case 2:
					cout << "Going to ACTION LIST...\n";
					Sleep(100);
					goto menu_ptr;
				}
			}

		case 3:
			while (main_choice == 1) {
				system("cls");
				LG.OpenFridgeDoor();
				cout << endl;
				cout << endl;
				cout << "1. Put some products \n";
				cout << "2. Take some products \n";
				cout << endl;
				cout << "3. Close the door\n";
				int number = 0;
				int switch_counter = 0;
				cin >> choice;
				switch (choice) {
				case 1:
					if (LG.CCam.GetVolume() == 0) {
						cout << "Fridge is full\n";
						break;
					}
					cout << "Enter the number of product you will put\n";
					cin >> number;
					if (LG.CCam.GetVolume() > 0) {
						LG.AddObject_c(number);
						Sleep(2000);
						LG.CCam.GetVolume();
						break;
					}
				case 2:
					if (LG.CCam.GetVolume() == FRIDGE_CAP) {
						cout << "Fridge is empty\n";
						Sleep(2000);
						break;
					}
					else if ((LG.CCam.GetVolume() >= 0) && (LG.CCam.GetVolume() <= 240)) {
						cout << "Enter the number of product you will take\n";
						cin >> number;
						LG.RemObject_c(number);
						LG.CCam.GetVolume();
					}
					break;
				case 3:
					LG.CCam.OpenDoor(false);
					cout << "Door is closed\n";
					Sleep(2000);
					system("cls");
					goto menu_ptr;
				}
			}

		case 4:
			while (main_choice == 1) {

				system("cls");
				LG.OpenFreezerDoor();
				cout << endl;
				cout << endl;
				cout << "1. Put some products \n";
				cout << "2. Take some products \n";
				cout << endl;
				cout << "3. Close the door\n";
				int number = 0;
				int switch_counter = 0;
				cin >> choice;
				switch (choice) {
				case 1:
					if (LG.FCam.GetVolume() == 0) {
						cout << "Freezer is full\n";
						break;
					}
					cout << "Enter the number of product you will put: ";
					cin >> number;
					if (LG.FCam.GetVolume() > 0) {
						LG.AddObject_f(number);
						Sleep(2000);
						LG.FCam.GetVolume();
						break;
					}
				case 2:
					if (LG.FCam.GetVolume() == FREEZER_CAP) {
						cout << "Freezer is empty\n";
						Sleep(2000);
						break;
					}
					else if ((LG.FCam.GetVolume() >= 0) && (LG.FCam.GetVolume() <= 130)) {
						cout << "Enter the number of product you will take: ";
						cin >> number;
						LG.RemObject_f(number);
						LG.FCam.GetVolume();
					}
					break;
				case 3:
					LG.FCam.OpenDoor(false);
					cout << "Door is closed\n";
					Sleep(2000);
					system("cls");
					goto menu_ptr;
				}
			}
	}
}
}
