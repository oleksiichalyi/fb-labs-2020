#ifndef _UTILS_H_
#define _UTILS_H_
struct RSA1024KeyExchBLOB
{
  PUBLICKEYSTRUC publickeystruc;
  ALG_ID algid;
  BYTE encryptedkey[1024/8];
};
#define BUFFER_SIZE (1<<14)
typedef struct
{
  struct RSA1024KeyExchBLOB kb;
  unsigned __int64 fSize;
} EncFileHeader;
#endif
