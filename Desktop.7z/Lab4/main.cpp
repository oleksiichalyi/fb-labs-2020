#include <iostream>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <iterator>
#include <vector>

using namespace std;

class User
{
public:
    User();
   /* void turnOnFridge();
    void turnOffFridge();
    void setCoolerTemp();
    void setFreezerTemp();
    void selectMode();
    void openCoolerDoor();
    void closeCoolerDoor();
    void openFreezerDoor();
    void closeFreezerDoor();
    void putfood();
    void takefood();
*/private:
    string name;
};

User::User()
{
    name = "Aleksey";
}



class Signalling
{
public:
    Signalling();
    bool sound();
private:
    int volume;
};

Signalling::Signalling()
{
   volume = 20;
}
bool Signalling::sound()
{
    cout << "Volume is set!"<<endl;
    return true;
}





class Screen
{
public:
    Screen();
    string getinput;
private:
    int size;
    bool state;
};

Screen::Screen()
{
    size = 10;
    cin >> getinput;
    state = false;
}






class ControlSystem
{
public:
    ControlSystem();
    bool commandFreezerOn();
    bool commandCoolerOn();
    bool commandFreezerOff();
    bool commandCoolerOff();
 //   void setTempFreezer();
  //  void setTempCooler();
private:
    int Mode;
    int minTempFreezer;
    int maxTempFreezer;
    int minTempCooler;
    int maxTempCooler;
    Signalling signalling;
};

ControlSystem::ControlSystem()
{
    signalling = Signalling();
    Mode = 3;
    minTempFreezer = rand() % 2 + (-26); //-24 - -26
    maxTempFreezer = rand() % 2 + (-3); //  -3 - -1
    minTempCooler = rand() % 1 + 3; // 1 - 3
    maxTempCooler = rand() % 2 + 13; // 13 - 15
}

bool ControlSystem::commandFreezerOn()
{
cout << "Freezer set is On" <<endl;
return true;
}

bool ControlSystem::commandCoolerOn()
{
cout << "Cooler set is On" <<endl;
return true;
}

bool ControlSystem::commandFreezerOff()
{
cout << "Freezer set is Off" <<endl;
return true;
}

bool ControlSystem::commandCoolerOff()
{
cout << "Cooler set is Off" <<endl;
return true;
}




class FreezerDoor
{
public:
    FreezerDoor();
   // void setstat();
    bool getstate();
private:
    string material;
    bool state;
};

FreezerDoor::FreezerDoor()
{
    material = "zalizo";
    state = false;
}

bool FreezerDoor::getstate()
{
cout << "State was get"<<endl;
return true;
}



class Freezer
{
public:
    Freezer();
private:
    int size;
    string material;
    FreezerDoor door;
};

Freezer::Freezer()
{
    size = rand() % 10 + 245; //245-255
    material = "Plastik";
    door = FreezerDoor();
}



class TermoregulationSystem1
{
public:
    TermoregulationSystem1();
    void setTemps();
    void termoregulation();
private:
    bool state;
    int minTemp;
    int maxTemp;
};

TermoregulationSystem1::TermoregulationSystem1()
{
    state = false;
    minTemp =rand() % 2 + (-26); //-24 - -26
    maxTemp = rand() % 2 + (-3); //  -3 - -1
}




class Temperatureloweringsystem1
{
public:
    Temperatureloweringsystem1();
    bool loweringTemp();
private:
    bool state;
};

Temperatureloweringsystem1::Temperatureloweringsystem1()
{
    state = false;
}
bool Temperatureloweringsystem1::loweringTemp()
{
    cout << "Temparute is lowing" <<endl;
    return true;
}





class Freezingsystem
{
public:
    Freezingsystem();
private:
    TermoregulationSystem1 Termoregulation;
    Temperatureloweringsystem1 loweringTemp;
};

Freezingsystem::Freezingsystem()
{
Termoregulation = TermoregulationSystem1();
loweringTemp = Temperatureloweringsystem1();
}



class Wire
{
public:
    Wire();
private:
    int length;
    string material;
};

Wire::Wire()
{
    length = rand() % 0,5 + (1,5); // 1.5 - 2 m
    material = "coaxial";
}




class Rosette
{
public:
    Rosette();
 //   void setstate();
    bool getstate();
private:
    string type;
    bool state;
};

Rosette::Rosette()
{
    type = "A++";
    state = false;
}

bool Rosette::getstate()
{
    cout << "State is get" <<endl;
    return true;
}




class Powersupplysystem
{
public:
    Powersupplysystem();
    bool energysupply();
private:
    Rosette rosette;
    Wire wire;
};

Powersupplysystem::Powersupplysystem()
{
    wire = Wire();
    rosette = Rosette();
}

bool Powersupplysystem::energysupply()
{
    cout <<"Energy is present"<<endl;
    return true;
}





class TermoregulationSystem2
{
public:
    TermoregulationSystem2();
   // void setTemps();
  //  void termoregulation();
private:
    bool state;
    int minTemp;
    int maxTemp;
};

TermoregulationSystem2::TermoregulationSystem2()
{
    state = false;
    minTemp = rand() % 1 + 3; // 1 - 3
    maxTemp = rand() % 2 + 13; // 13 - 15
}





class Temperatureloweringsystem2
{
public:
    Temperatureloweringsystem2();
    bool loweringTemp();
private:
    bool state;
};

Temperatureloweringsystem2::Temperatureloweringsystem2()
{
    state = false;
}

bool Temperatureloweringsystem2::loweringTemp()
{
cout << "Temperature is lowing"<<endl;
}


class Coolingsystem
{
public:
    Coolingsystem();
private:
    TermoregulationSystem2 Termoregulation;
    Temperatureloweringsystem2 loweringTemp;
};

Coolingsystem::Coolingsystem()
{
    Termoregulation = TermoregulationSystem2();
    loweringTemp = Temperatureloweringsystem2();
}





class CoolerDoor
{
public:
    CoolerDoor();
   // void setstate();
    bool getstate();
private:
    string material;
    bool state;
};

CoolerDoor::CoolerDoor()
{
    state = false;
    material = "Zalizo";
}

bool CoolerDoor::getstate()
{
cout << "State is get"<<endl;
return true;
}





class Lightningsystem
{
public:
    Lightningsystem();
    bool poweron();
    bool poweroff();
private:
    int power;
    bool state;
};

Lightningsystem::Lightningsystem()
{
    power = rand() % 30 + 210; // 210-240 V
    state = false;
}

bool Lightningsystem::poweron()
{
    cout << " Power is on" <<endl;
    return true;
}

bool Lightningsystem::poweroff()
{
    cout << " Power is off" <<endl;
    return true;
}




class Doorcontrolsystem
{
public:
    Doorcontrolsystem();
    bool doorcheck();
    bool light();
   // int getdoortime();
    bool sendsignal();
private:
    bool state;
};

Doorcontrolsystem::Doorcontrolsystem()
{
    state = false;
   // getdoortime = rand() % 10 + 60; //60 - 70 c
}

bool Doorcontrolsystem::doorcheck()
{
    cout << "Door is ok"<<endl;
    return true;
}

bool Doorcontrolsystem::light()
{
    cout << "Light is on" <<endl;
    return true;
}

bool Doorcontrolsystem::sendsignal()
{
    cout << "Signal is sent"<<endl;
    return true;
}



class Cooler
{
public:
    Cooler();
private:
    int size;
    string material;
    Lightningsystem lightning;
    Doorcontrolsystem doorcontrol;
    CoolerDoor door;
};

Cooler::Cooler()
{
    size = rand() % 10 + 125; // 125 - 135 L
    material = "Zalizo";
    lightning = Lightningsystem();
    doorcontrol = Doorcontrolsystem();
    door = CoolerDoor();
}





class Timer
{
public:
    Timer();
    bool countfreezertime();
    bool countcoolertime();
    bool countdoortime();
private:
    int freezertime;
    int coolertime;
    int doortime;
    bool state;
};

Timer::Timer()
{
    state = false;
    freezertime = 90; //90 c
    coolertime = rand() % 10 + 80; //80 - 90 c
    doortime = rand() % 10 + 60; //60 - 70 c
}

bool Timer::countfreezertime()
{
    if (freezertime >= 90)
    cout << "Freeze is ok. Check Freeze Temperature"<<endl;
    return true;
}

bool Timer::countcoolertime()
{
    if (coolertime >= rand() % 10 + 80 )
    cout << "Cooler is ok. Check Cooler Temperature"<<endl;
    return true;
}

bool Timer::countdoortime()
{
    if (doortime >= rand() % 10 + 60)
    cout << "Please close your door!"<<endl;
    return true;
}




class Refrigerator
{
public:
    Refrigerator();
   bool lowingtemperature();
private:
    ControlSystem controlpanel;
    Powersupplysystem powersupply;
    Cooler cooler;
    Freezer freezer;
    Coolingsystem coolingsystem;
    Freezingsystem freezingsystem;
    Timer timer;
    bool state;
};

Refrigerator::Refrigerator()
{
    controlpanel = ControlSystem();
    powersupply = Powersupplysystem();
    cooler = Cooler();
    freezer = Freezer();
    coolingsystem = Coolingsystem();
    freezingsystem = Freezingsystem();
    timer = Timer();
    state = false;
}












int main()
{



//cout << controlpanel.commandFreezerOn();


cout <<1+2;







    return 0;
}















